document.documentElement.classList.add('js');

// Плавное появление блоков при скролле
(function () {
  var items = document.querySelectorAll('.promo__grid, .section .wrap');
  items.forEach(function (el) { el.classList.add('reveal'); });
  if (!('IntersectionObserver' in window)) {
    items.forEach(function (el) { el.classList.add('is-visible'); });
    return;
  }
  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      if (e.isIntersecting) { e.target.classList.add('is-visible'); io.unobserve(e.target); }
    });
  }, { threshold: 0.15 });
  items.forEach(function (el) { io.observe(el); });
})();

// Маска телефона и отправка формы (демо: без сервера)
// Ключ Web3Forms (публичный): получить на web3forms.com, указав почту для заявок
var WEB3FORMS_KEY = '2da9bdd0-9af5-4827-9e1e-d838a9176fc0';

(function () {
  var form = document.getElementById('signup-form');
  if (!form) return;
  var msg = document.getElementById('form-msg');
  var phone = form.elements.phone;

  phone.addEventListener('input', function () {
    var d = phone.value.replace(/\D/g, '');
    if (d[0] === '8' || d[0] === '7') d = d.slice(1);
    d = d.slice(0, 10);
    var out = '+7';
    if (d.length) out += ' (' + d.slice(0, 3);
    if (d.length >= 3) out += ') ' + d.slice(3, 6);
    if (d.length >= 6) out += '-' + d.slice(6, 8);
    if (d.length >= 8) out += '-' + d.slice(8, 10);
    phone.value = d.length ? out : '';
  });

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var ok = true;
    Array.prototype.forEach.call(form.elements, function (f) {
      if (!f.name || f.type === 'hidden' || f.name === 'botcheck') return;
      var bad = !f.value.trim() || (f.name === 'phone' && f.value.replace(/\D/g, '').length < 11);
      f.classList.toggle('is-invalid', bad);
      if (bad) ok = false;
    });
    msg.className = 'form__msg ' + (ok ? 'is-ok' : 'is-error');
    if (!ok) { msg.textContent = 'Проверьте поля: заполните имя, телефон и возраст.'; return; }

    var btn = form.querySelector('button[type="submit"]');
    btn.disabled = true;
    msg.className = 'form__msg';
    msg.textContent = 'Отправляем…';

    var fail = function () {
      msg.className = 'form__msg is-error';
      msg.textContent = 'Не удалось отправить заявку. Позвоните нам: +7 (926) 139-21-70';
      btn.disabled = false;
    };
    if (form.elements.botcheck.checked) { fail(); return; }
    if (WEB3FORMS_KEY.indexOf('ВСТАВЬТЕ') === 0) { fail(); return; }

    fetch('https://api.web3forms.com/submit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify({
        access_key: WEB3FORMS_KEY,
        subject: 'Новая заявка с сайта MK TEAM',
        from_name: 'Сайт MK TEAM',
        'Имя': form.elements.name.value.trim(),
        'Телефон': form.elements.phone.value,
        'Возраст занимающегося': form.elements.age.value
      })
    }).then(function (r) { return r.json(); }).then(function (d) {
      if (!d.success) throw new Error('rejected');
      msg.className = 'form__msg is-ok';
      msg.textContent = 'Спасибо! Заявка отправлена, мы скоро свяжемся с вами.';
      form.reset();
      btn.disabled = false;
    }).catch(fail);
  });
})();

// Фоновые видео: на телефоне — облегчённая версия, при экономии трафика / медленной сети — только картинка.
// Видео «О клубе» начинает грузиться, только когда до него докрутили.
(function () {
  var conn = navigator.connection || {};
  var saveData = conn.saveData || /(^|-)2g$/.test(conn.effectiveType || '');
  var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var mobile = window.matchMedia && matchMedia('(max-width: 767px)').matches;
  if (saveData || reduce) return; // остаётся постер

  function start(v) {
    if (v.getAttribute('src')) return;
    v.addEventListener('error', function () { v.remove(); }); // файла нет — остаётся фон
    v.src = (mobile && v.getAttribute('data-src-mobile')) || v.getAttribute('data-src');
    v.load();
    var p = v.play();
    if (p && p.catch) p.catch(function () {});
  }

  document.querySelectorAll('video[data-src]').forEach(function (v) {
    if (!v.hasAttribute('data-lazy') || !('IntersectionObserver' in window)) { start(v); return; }
    var io = new IntersectionObserver(function (entries) {
      if (entries[0].isIntersecting) { start(v); io.disconnect(); }
    }, { rootMargin: '300px 0px' });
    io.observe(v);
  });
})();
